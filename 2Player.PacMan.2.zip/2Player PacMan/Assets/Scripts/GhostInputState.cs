﻿//LARD (Troy, 3/1/16)

using UnityEngine;
using System.Collections;

public class GhostInputState : MonoBehaviour {
	
	public int direction;	//0=left, 1=up, 2=right, 3=down
	public float absVelX = 0f;
	public float absVelY = 0f;
	
	private Rigidbody2D body2d;
	
	void Awake(){
		body2d = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.A)) {
			direction = 0;
		} else if (Input.GetKeyDown (KeyCode.W)) {
			direction = 1;
		} else if (Input.GetKeyDown (KeyCode.D)) {
			direction = 2;
		} else if (Input.GetKeyDown (KeyCode.S)) {
			direction = 3;
		}
	}
	
	void FixedUpdate(){
		absVelX = System.Math.Abs (body2d.velocity.x);
		absVelY = System.Math.Abs (body2d.velocity.y);
	}
}
