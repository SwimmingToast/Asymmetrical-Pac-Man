﻿//Animation is real, right?! (Ruoya 2/29/16)

using UnityEngine;
using System.Collections;

public class PacManAnimation : MonoBehaviour {
	private Animator animator;
	private PacManInputState inputState;
	
	// Use this for initialization
	void Awake () {
		
		animator = GetComponent<Animator> ();
		inputState = GetComponent<PacManInputState> ();
	}
	
	// Update is called once per frame
	void Update () {
		
		int direction = inputState.direction;
		animator.SetInteger ("direction", direction);

	}
}
