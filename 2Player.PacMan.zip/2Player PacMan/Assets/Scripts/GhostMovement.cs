﻿//Ruoya 3/1/16

using UnityEngine;
using System.Collections;

public class GhostMovement : MonoBehaviour {
	
	public Vector2 velocity = Vector2.zero;
	public float speed = 60f;
	
	private Rigidbody2D body2d;
	private GhostInputState input;
	
	void Awake(){
		body2d = GetComponent<Rigidbody2D> ();
		input = GetComponent<GhostInputState> ();
	}
	
	void FixedUpdate(){
		int direction = input.direction;	//0=left, 1=up, 2=right, 3=down
		switch (direction) {
		case 0:
			velocity = new Vector2 (-speed, 0);
			break;
		case 1:
			velocity = new Vector2 (0, speed);
			break;
		case 2:
			velocity = new Vector2 (speed, 0);
			break;
		case 3:
			velocity = new Vector2 (0, -speed);
			break;
		}
		body2d.velocity = velocity;
	}
}
