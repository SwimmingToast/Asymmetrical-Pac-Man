﻿//Ruoya 2/29/16

using UnityEngine;
using System.Collections;

public class PacManMovement : MonoBehaviour {

	public Vector2 velocity = Vector2.zero;
	
	private Rigidbody2D body2d;
	private PacManInputState input;
	
	void Awake(){
		body2d = GetComponent<Rigidbody2D> ();
	}
	
	void FixedUpdate(){
		body2d.velocity = velocity;
	}
}
