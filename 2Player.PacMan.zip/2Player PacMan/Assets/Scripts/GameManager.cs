﻿//COMMENCE MICRO-MANAGEMENT! (Ruoya 2/29/16)

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class GameManager : MonoBehaviour {

	public GameObject pacMan;
	
	public static int ghostSelected;	//1, 2, or 3
	public static bool powerup;
	public static bool powerupEnding;

	public static bool gameStarted;

	private AudioSource source;
	public AudioClip crashSound;
	public float vol = 0.25f;

	void Awake(){
		ghostSelected = 1;
		//source = GetComponent<AudioSource> ();
	}

	// Use this for initialization
	void Start () {
		gameStarted = false;

		powerup = false;
		powerupEnding = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Q)) {
			changeGhostSelected();
		}
	}

	public static void changeGhostSelected ()
	{
		ghostSelected++;
		if (ghostSelected > 4) {
			ghostSelected = 1;
		}
	}
}
