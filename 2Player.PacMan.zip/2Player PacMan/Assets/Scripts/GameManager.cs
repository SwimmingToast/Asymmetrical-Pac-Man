﻿//COMMENCE MICRO-MANAGEMENT! (Ruoya 2/29/16)

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class GameManager : MonoBehaviour {

	public GameObject pacMan;
	public GameObject ghost1;
	public GameObject ghost2;
	public GameObject ghost3;

	public static int ghostSelected;	//1, 2, or 3

	public static bool gameStarted;

	private AudioSource source;
	public AudioClip crashSound;
	public float vol = 0.25f;

	void Awake(){
		ghostSelected = 1;
		//source = GetComponent<AudioSource> ();
	}

	// Use this for initialization
	void Start () {
		gameStarted = false;


	}
	
	// Update is called once per frame
	void Update () {

	}



}
