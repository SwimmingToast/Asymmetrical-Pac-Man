﻿// I guess you could say this script is spooky? (Troy, 3/1/16)

using UnityEngine;
using System.Collections;

public class GhostAnimation : MonoBehaviour {
	private Animator animator;
	private GhostInputState inputState;
	
	// Use this for initialization
	void Awake () {
		
		animator = GetComponent<Animator> ();
		inputState = GetComponent<GhostInputState> ();
	}
	
	// Update is called once per frame
	void Update () {
		
		animator.SetInteger ("direction", inputState.direction);
		animator.SetBool ("controlled", inputState.controlled);
		animator.SetBool ("powerup", GameManager.powerup);
		animator.SetBool ("powerupending", GameManager.powerupEnding);

	}
}
