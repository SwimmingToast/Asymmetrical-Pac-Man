﻿using UnityEngine;
using System.Collections;

public class Pellet : MonoBehaviour {

	void OnTriggerEnter2D (Collider2D other) {
		if (other.gameObject.tag.Equals("PacMan")) {
			GameManager.pelletsLeft--;
			Destroy (gameObject);
		}
		Debug.Log (other.gameObject.tag);
	}

}
